public class Node
{
    String data;
    Node left;
    Node right;
    int cnt; 

    public Node(String s)
    {
        data = s;
        left = null;
        right = null;
        cnt = 1;
    }

}